### Still In Progress

### How To Use
```
git clone https://github.com/lintangtimur/rfid-absensi-v2.git
composer install
php artisan migrate:fresh --seed
```
