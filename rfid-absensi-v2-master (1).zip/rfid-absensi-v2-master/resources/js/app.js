import './bootstrap';

alert("LINTANG")